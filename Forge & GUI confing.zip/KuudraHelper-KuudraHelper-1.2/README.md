**__KuudraHelper__**
Introducing "KuudraHelper," a captivating Java mod designed to enhance the Kuudra quest experience in Hypixel Skyblock. . This mod seamlessly integrates a challenging yet rewarding puzzle-solving mechanism, adding an extra layer of ihelp to the quest. 

This Mod Is An Open Source Code Mod

KuudraHelper helps with kuudras quest and it shows all the locations of the npcs in crimson isle & Spider's Den

**PLEASE NOTE:** This is a forge mod. Not a spigot plugin. Use the forge mod loader to use this mod for yourself.

**Usage** Download the jar file from the top of the page and place it into your minecraft installation's mod folder (usually %appdata%/.minecraft/mods) Start minecraft with forge and enjoy!

How to use You can configure the mod in the mods menu. Check your forge installaton on where to find the settings panel

**Commands** /kf - Opens the mod menu with a guide on how to use the mod effectively

